package com.android.rustmdm.lib

import android.content.Context
import android.util.Log
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

/**
 * Checks remote DEX metadata and downloads updates into app-private storage.
 */
class DexUpdater(
    private val context: Context,
    private val client: OkHttpClient = defaultClient(),
    private val baseUrl: String = ServerConfig.baseUrl,
) {
    private val dexDir: File = File(context.filesDir, "hot_dex").also { it.mkdirs() }
    private val dexFile: File = File(dexDir, "payload.dex")
    private val localManifestFile: File = File(dexDir, "manifest.json")

    fun localDexFile(): File = dexFile

    fun localManifest(): DexManifest? {
        if (!localManifestFile.exists() || !dexFile.exists()) return null
        return runCatching { DexManifest.fromJson(localManifestFile.readText()) }.getOrNull()
    }

    fun ensureLatest(): Result<DexManifest> = runCatching {
        val remote = fetchRemoteManifest()
        val local = localManifest()
        if (local != null &&
            local.version >= remote.version &&
            local.sha256.equals(remote.sha256, ignoreCase = true) &&
            dexFile.exists()
        ) {
            Log.i(TAG, "DEX up-to-date version=${local.version}")
            return@runCatching local
        }
        downloadAndVerify(remote)
        localManifestFile.writeText(
            """{"version":${remote.version},"sha256":"${remote.sha256}","size":${remote.size},"entryClass":"${remote.entryClass}"}""",
        )
        Log.i(TAG, "DEX updated to version=${remote.version}")
        remote
    }

    private fun fetchRemoteManifest(): DexManifest {
        val request = Request.Builder()
            .url("$baseUrl/api/v1/dex/latest")
            .get()
            .build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                error("manifest HTTP ${response.code}")
            }
            val body = response.body?.string().orEmpty()
            return DexManifest.fromJson(body)
        }
    }

    private fun downloadAndVerify(manifest: DexManifest) {
        val request = Request.Builder()
            .url("$baseUrl/api/v1/dex/download")
            .get()
            .build()
        val tmp = File(dexDir, "payload.dex.tmp")
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                error("download HTTP ${response.code}")
            }
            val bytes = response.body?.bytes() ?: error("empty DEX body")
            val digest = sha256Hex(bytes)
            if (!digest.equals(manifest.sha256, ignoreCase = true)) {
                error("sha256 mismatch: expected=${manifest.sha256} actual=$digest")
            }
            tmp.writeBytes(bytes)
        }
        if (!tmp.renameTo(dexFile)) {
            tmp.copyTo(dexFile, overwrite = true)
            tmp.delete()
        }
    }

    companion object {
        private const val TAG = "DexUpdater"

        private fun defaultClient(): OkHttpClient =
            OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .build()

        fun sha256Hex(bytes: ByteArray): String {
            val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
            return digest.joinToString("") { "%02x".format(it) }
        }
    }
}
