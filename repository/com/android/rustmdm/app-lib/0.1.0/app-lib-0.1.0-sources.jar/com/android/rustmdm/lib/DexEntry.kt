package com.android.rustmdm.lib

import android.content.Context

/**
 * Contract implemented by hot-fix DEX (`app_dex`).
 * Host loads the implementation via [DexLoader] using a fixed FQCN.
 */
interface DexEntry {
    fun onLoad(context: Context, args: Map<String, String> = emptyMap())
}
