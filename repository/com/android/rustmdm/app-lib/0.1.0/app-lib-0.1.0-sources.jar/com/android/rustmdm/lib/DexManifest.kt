package com.android.rustmdm.lib

import org.json.JSONObject

data class DexManifest(
    val version: Int,
    val sha256: String,
    val size: Long,
    val entryClass: String = DexLoader.DEFAULT_ENTRY_CLASS,
    val hotfixVersion: String = "",
) {
    companion object {
        fun fromJson(json: String): DexManifest {
            val obj = JSONObject(json)
            return DexManifest(
                version = obj.getInt("version"),
                sha256 = obj.getString("sha256"),
                size = obj.optLong("size", 0L),
                entryClass = obj.optString("entryClass", DexLoader.DEFAULT_ENTRY_CLASS),
                hotfixVersion = obj.optString("hotfixVersion", ""),
            )
        }
    }
}
