package com.android.rustmdm.lib

/**
 * Server endpoint owned by app_lib.
 *
 * Host apps must not put this in their Manifest — they only depend on the Maven
 * artifact. Change the URL here and publish a new app_lib version.
 */
object ServerConfig {
    /**
     * Default rust_server base URL baked into the shell.
     * Emulator → host loopback for early experiment; replace before OEM release.
     */
    const val DEFAULT_BASE_URL: String = "http://10.18.16.247:8080"

    @Volatile
    var baseUrl: String = DEFAULT_BASE_URL
}
