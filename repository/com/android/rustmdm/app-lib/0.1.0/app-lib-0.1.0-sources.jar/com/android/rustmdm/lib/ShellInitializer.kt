package com.android.rustmdm.lib

import android.content.Context
import android.util.Log
import androidx.startup.Initializer
import java.util.concurrent.Executors

/**
 * AndroidX App Startup entry. Merged into host APK via library manifest —
 * host only needs `implementation(project(":app_lib"))`.
 *
 * Network + DEX load run off the main thread so process start is not blocked.
 */
class ShellInitializer : Initializer<Unit> {
    override fun create(context: Context) {
        Log.i(TAG, "App Startup: scheduling shell bootstrap")
        val appContext = context.applicationContext
        EXECUTOR.execute {
            ShellBootstrap.start(appContext)
        }
    }

    override fun dependencies(): List<Class<out Initializer<*>>> = emptyList()

    companion object {
        private const val TAG = "ShellInitializer"
        private val EXECUTOR = Executors.newSingleThreadExecutor { runnable ->
            Thread(runnable, "rust-mdm-shell").apply { isDaemon = true }
        }
    }
}
