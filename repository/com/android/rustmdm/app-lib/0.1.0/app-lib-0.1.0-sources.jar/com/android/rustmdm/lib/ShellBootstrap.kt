package com.android.rustmdm.lib

import android.content.Context
import android.util.Log

/**
 * Shell entry: check/download DEX then load business entry.
 * Prefer triggering via [ShellInitializer] (App Startup); host app needs no call sites.
 */
object ShellBootstrap {
    private const val TAG = "ShellBootstrap"

    @Volatile
    var lastError: Throwable? = null
        private set

    @Volatile
    var started: Boolean = false
        private set

    fun start(context: Context, args: Map<String, String> = emptyMap()): Result<Unit> =
        runCatching {
            val appContext = context.applicationContext
            val updater = DexUpdater(appContext)
            val manifest = updater.ensureLatest().getOrElse { error ->
                val fallback = updater.localManifest()
                if (fallback != null && updater.localDexFile().exists()) {
                    Log.w(TAG, "update failed, using cached DEX: ${error.message}")
                    fallback
                } else {
                    throw error
                }
            }
            val entry = DexLoader(appContext).loadEntry(
                dexFile = updater.localDexFile(),
                entryClass = manifest.entryClass,
            )
            entry.onLoad(appContext, args)
            started = true
            lastError = null
            Log.i(TAG, "DEX entry loaded version=${manifest.version}")
            Unit
        }.onFailure { error ->
            started = false
            lastError = error
            Log.e(TAG, "bootstrap failed", error)
        }
}
