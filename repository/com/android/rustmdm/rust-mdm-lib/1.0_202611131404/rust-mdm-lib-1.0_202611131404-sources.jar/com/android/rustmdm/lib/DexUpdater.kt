package com.android.rustmdm.lib

import android.content.Context
import android.util.Log
import androidx.core.net.toUri
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileInputStream
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

/**
 * Checks remote DEX metadata and downloads updates into app-private storage.
 *
 * Manifest is fetched from rust_server (or configured base URL); the DEX binary
 * itself is downloaded from [DexManifest.fileUrl] when present (CDN / file host /
 * local file URI), otherwise from the server download API.
 */
class DexUpdater(
    context: Context,
    private val client: OkHttpClient = defaultClient(),
    private val baseUrl: String = ServerConfig.baseUrl,
) {
    private val dexDir: File = File(context.filesDir, "hot_dex").also { it.mkdirs() }
    private val dexFile: File = File(dexDir, "payload.dex")
    private val localManifestFile: File = File(dexDir, "manifest.json")

    fun localDexFile(): File = dexFile

    fun localManifest(): DexManifest? {
        if (!localManifestFile.exists() || !dexFile.exists()) return null
        return runCatching { DexManifest.fromJson(localManifestFile.readText()) }.getOrNull()
    }

    fun ensureLatest(): Result<DexManifest> = runCatching {
        val remote = fetchRemoteManifest()
        require(remote.version > 0 && remote.size > 0L && remote.sha256.isNotBlank()) {
            "remote DEX not ready (version=${remote.version}, size=${remote.size}); run :app_dex:packageHotfixDex"
        }
        val local = localManifest()
        if (local != null && local.version > 0 && local.size > 0L && local.version >= remote.version && local.sha256.equals(
                remote.sha256,
                ignoreCase = true
            ) && dexFile.exists() && dexFile.length() > 0L
        ) {
            Log.i(TAG, "DEX up-to-date version=${local.version}")
            return@runCatching local
        }
        downloadAndVerify(remote)
        localManifestFile.writeText(remote.toJson())
        Log.i(
            TAG,
            "DEX updated to version=${remote.version} from ${remote.resolveDownloadUrl(baseUrl)}"
        )
        remote
    }

    private fun fetchRemoteManifest(): DexManifest {
        val request = Request.Builder().url("$baseUrl/api/v1/dex/latest").get().build()
        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                error("manifest HTTP ${response.code}")
            }
            val body = response.body.string()
            return DexManifest.fromJson(body)
        }
    }

    private fun downloadAndVerify(manifest: DexManifest) {
        val url = manifest.resolveDownloadUrl(baseUrl)
        Log.i(TAG, "downloading DEX from $url")
        val bytes = readBytes(url)
        require(bytes.isNotEmpty()) { "downloaded DEX is empty from $url" }
        val digest = sha256Hex(bytes)
        if (!digest.equals(manifest.sha256, ignoreCase = true)) {
            error("sha256 mismatch: expected=${manifest.sha256} actual=$digest")
        }
        if (manifest.size > 0L && bytes.size.toLong() != manifest.size) {
            Log.w(TAG, "size mismatch: manifest=${manifest.size} actual=${bytes.size}")
        }
        val tmp = File(dexDir, "payload.dex.tmp")
        tmp.writeBytes(bytes)
        if (!tmp.renameTo(dexFile)) {
            tmp.copyTo(dexFile, overwrite = true)
            tmp.delete()
        }
    }

    private fun readBytes(url: String): ByteArray {
        val uri = url.toUri()
        return when (uri.scheme?.lowercase()) {
            "file" -> {
                val path = uri.path ?: error("invalid file URL: $url")
                FileInputStream(File(path)).use { it.readBytes() }
            }

            "http", "https", null -> {
                val request = Request.Builder().url(url).get().build()
                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        error("download HTTP ${response.code} url=$url")
                    }
                    response.body.bytes()
                }
            }

            else -> error("unsupported DEX URL scheme: ${uri.scheme}")
        }
    }

    companion object {
        private const val TAG = "DexUpdater"

        private fun defaultClient(): OkHttpClient =
            OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS).build()

        fun sha256Hex(bytes: ByteArray): String {
            val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
            return digest.joinToString("") { "%02x".format(it) }
        }
    }
}
