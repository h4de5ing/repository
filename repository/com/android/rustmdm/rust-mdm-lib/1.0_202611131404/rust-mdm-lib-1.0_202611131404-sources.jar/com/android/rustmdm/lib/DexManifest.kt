package com.android.rustmdm.lib

import org.json.JSONObject

/**
 * Hot-fix DEX metadata.
 *
 * [fileUrl] is the actual download location of the DEX binary. It may point at
 * rust_server, a CDN, object storage, or a device/shared filesystem URL — not
 * necessarily the same host that serves this manifest.
 */
data class DexManifest(
    val version: Int,
    val sha256: String,
    val size: Long,
    val entryClass: String = DexLoader.DEFAULT_ENTRY_CLASS,
    val hotfixVersion: String = "",
    /** Absolute URL (http/https/file) of the DEX payload. Empty → fallback download API. */
    val fileUrl: String = "",
) {
    /**
     * Resolve where to fetch the DEX bytes.
     * Prefer [fileUrl]; otherwise fall back to rust_server download endpoint.
     */
    fun resolveDownloadUrl(serverBaseUrl: String): String {
        val trimmed = fileUrl.trim()
        if (trimmed.isNotEmpty()) return trimmed
        return "${serverBaseUrl.trimEnd('/')}/api/v1/dex/download"
    }

    fun toJson(): String =
        JSONObject()
            .put("version", version)
            .put("sha256", sha256)
            .put("size", size)
            .put("entryClass", entryClass)
            .put("hotfixVersion", hotfixVersion)
            .put("fileUrl", fileUrl)
            .toString()

    companion object {
        fun fromJson(json: String): DexManifest {
            val obj = JSONObject(json)
            return DexManifest(
                version = obj.getInt("version"),
                sha256 = obj.getString("sha256"),
                size = obj.optLong("size", 0L),
                entryClass = obj.optString("entryClass", DexLoader.DEFAULT_ENTRY_CLASS),
                hotfixVersion = obj.optString("hotfixVersion", ""),
                // Accept camelCase (preferred) and snake_case from external hosts.
                fileUrl = obj.optString("fileUrl")
                    .ifEmpty { obj.optString("file_url", "") },
            )
        }
    }
}
