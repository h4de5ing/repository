package com.android.rustmdm.lib

import android.content.Context
import android.os.Build
import android.util.Log
import dalvik.system.DexClassLoader
import dalvik.system.InMemoryDexClassLoader
import java.io.File
import java.nio.ByteBuffer

/**
 * Loads hot-fix DEX entry.
 *
 * - API 29..33: [DexClassLoader] from app-private file path
 * - API 34+ (Android 14+): [InMemoryDexClassLoader] to avoid path-based DEX
 *   restrictions on writable storage
 */
class DexLoader(
    private val context: Context,
) {
    fun loadEntry(dexFile: File, entryClass: String = DEFAULT_ENTRY_CLASS): DexEntry {
        require(dexFile.exists()) { "DEX not found: ${dexFile.absolutePath}" }
        require(dexFile.length() > 0L) { "DEX is empty: ${dexFile.absolutePath}" }
        val classLoader = createClassLoader(dexFile)
        val clazz = Class.forName(entryClass, true, classLoader)
        val instance = clazz.getDeclaredConstructor().newInstance()
        return instance as? DexEntry
            ?: error("$entryClass does not implement DexEntry")
    }

    private fun createClassLoader(dexFile: File): ClassLoader {
        val parent = context.classLoader
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            Log.i(TAG, "using InMemoryDexClassLoader (API ${Build.VERSION.SDK_INT})")
            val bytes = dexFile.readBytes()
            InMemoryDexClassLoader(ByteBuffer.wrap(bytes), parent)
        } else {
            Log.i(TAG, "using DexClassLoader (API ${Build.VERSION.SDK_INT})")
            val optimized = File(context.codeCacheDir, "hot_dex_opt").also { it.mkdirs() }
            DexClassLoader(
                dexFile.absolutePath,
                optimized.absolutePath,
                null,
                parent,
            )
        }
    }

    companion object {
        private const val TAG = "DexLoader"
        const val DEFAULT_ENTRY_CLASS = "com.android.rustmdm.dex.DexMain"
    }
}
