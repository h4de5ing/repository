package com.android.koogsystemonandroid.util

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager

/**
 * 获取设备上所有有桌面图标（Launcher）的已安装应用列表。
 * 返回格式: List<Pair<应用名, 包名>>，按应用名排序。
 */
fun getInstalledLauncherApps(context: Context): List<Pair<String, String>> {
    val intent = Intent(Intent.ACTION_MAIN, null).apply {
        addCategory(Intent.CATEGORY_LAUNCHER)
    }
    val pm = context.packageManager
    return pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        .map { resolveInfo ->
            val label = resolveInfo.loadLabel(pm).toString()
            val packageName = resolveInfo.activityInfo.packageName
            Pair(label, packageName)
        }
        .sortedBy { it.first }
        .distinctBy { it.second }
}

/**
 * 将已安装应用列表格式化为 system prompt 中的文本块。
 */
fun buildInstalledAppsPrompt(apps: List<Pair<String, String>>): String {
    if (apps.isEmpty()) return ""
    val appLines = apps.joinToString("\n") { (name, pkg) -> "  - $name: $pkg" }
    return """

Below is the list of installed apps on this device (App Name: Package Name).
Use the exact package name when calling launch_app:
$appLines
""".trimIndent()
}
