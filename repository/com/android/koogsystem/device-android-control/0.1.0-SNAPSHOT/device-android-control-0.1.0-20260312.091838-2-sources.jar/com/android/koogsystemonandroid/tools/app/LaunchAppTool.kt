package com.android.koogsystemonandroid.tools.app

import ai.koog.agents.core.tools.SimpleTool
import ai.koog.agents.core.tools.annotations.LLMDescription
import android.content.Context
import android.content.Intent
import kotlinx.serialization.Serializable

class LaunchAppTool(private val context: Context) : SimpleTool<LaunchAppTool.Args>(
    argsSerializer = Args.serializer(),
    name = "launch_app",
    description = "Launches an Android application by its package name. Use this when the user asks to open or start any app."
) {
    @Serializable
    data class Args(
        @property:LLMDescription("The Android package name of the app to launch, e.g. com.android.settings for Settings")
        val packageName: String
    )

    override suspend fun execute(args: Args): String {
        val intent = context.packageManager.getLaunchIntentForPackage(args.packageName)
            ?: return "Failed: No launch intent found for package '${args.packageName}'. The app may not be installed."
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return "Successfully launched '${args.packageName}'."
    }
}