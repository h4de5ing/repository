package com.android.koogsystemonandroid.tools.app

class ForceStopAppTool {
}