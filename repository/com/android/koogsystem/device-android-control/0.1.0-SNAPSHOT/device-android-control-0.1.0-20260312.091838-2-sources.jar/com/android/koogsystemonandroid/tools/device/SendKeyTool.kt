package com.android.koogsystemonandroid.tools.device

import ai.koog.agents.core.tools.SimpleTool
import ai.koog.agents.core.tools.annotations.LLMDescription
import android.app.Instrumentation
import android.view.KeyEvent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable

class SendKeyTool : SimpleTool<SendKeyTool.Args>(
    argsSerializer = Args.serializer(),
    name = "send_key",
    description = """Simulates a physical key press on the Android device using Instrumentation.
Supported key names: HOME, BACK, RECENTS, MENU, SEARCH,
VOLUME_UP, VOLUME_DOWN, POWER, SLEEP,
SCREENSHOT, CAMERA,
DPAD_UP, DPAD_DOWN, DPAD_LEFT, DPAD_RIGHT, DPAD_CENTER,
ENTER, DEL, TAB, SPACE, ESCAPE,
PAGE_UP, PAGE_DOWN, MOVE_HOME, MOVE_END,
CALL, ENDCALL,
BRIGHTNESS_UP, BRIGHTNESS_DOWN,
CUT, COPY, PASTE,
CONTACTS, CALENDAR, MUSIC,
EXPLORER, ENVELOPE, HEADSETHOOK, SYM."""
) {
    @Serializable
    data class Args(
        @property:LLMDescription(
            "The key to simulate. Must be one of the supported key names listed in the tool description, e.g. HOME, BACK, VOLUME_UP, SCREENSHOT."
        )
        val keyName: String
    )

    companion object {
        private val KEY_MAP = mapOf(
            "HOME"           to KeyEvent.KEYCODE_HOME,
            "BACK"           to KeyEvent.KEYCODE_BACK,
            "RECENTS"        to KeyEvent.KEYCODE_APP_SWITCH,
            "MENU"           to KeyEvent.KEYCODE_MENU,
            "SEARCH"         to KeyEvent.KEYCODE_SEARCH,
            "VOLUME_UP"      to KeyEvent.KEYCODE_VOLUME_UP,
            "VOLUME_DOWN"    to KeyEvent.KEYCODE_VOLUME_DOWN,
            "POWER"          to KeyEvent.KEYCODE_POWER,
            "SLEEP"          to KeyEvent.KEYCODE_SLEEP,
            "SCREENSHOT"     to KeyEvent.KEYCODE_SYSRQ,
            "CAMERA"         to KeyEvent.KEYCODE_CAMERA,
            "DPAD_UP"        to KeyEvent.KEYCODE_DPAD_UP,
            "DPAD_DOWN"      to KeyEvent.KEYCODE_DPAD_DOWN,
            "DPAD_LEFT"      to KeyEvent.KEYCODE_DPAD_LEFT,
            "DPAD_RIGHT"     to KeyEvent.KEYCODE_DPAD_RIGHT,
            "DPAD_CENTER"    to KeyEvent.KEYCODE_DPAD_CENTER,
            "ENTER"          to KeyEvent.KEYCODE_ENTER,
            "DEL"            to KeyEvent.KEYCODE_DEL,
            "TAB"            to KeyEvent.KEYCODE_TAB,
            "SPACE"          to KeyEvent.KEYCODE_SPACE,
            "ESCAPE"         to KeyEvent.KEYCODE_ESCAPE,
            "PAGE_UP"        to KeyEvent.KEYCODE_PAGE_UP,
            "PAGE_DOWN"      to KeyEvent.KEYCODE_PAGE_DOWN,
            "MOVE_HOME"      to KeyEvent.KEYCODE_MOVE_HOME,
            "MOVE_END"       to KeyEvent.KEYCODE_MOVE_END,
            "CALL"           to KeyEvent.KEYCODE_CALL,
            "ENDCALL"        to KeyEvent.KEYCODE_ENDCALL,
            "BRIGHTNESS_UP"  to KeyEvent.KEYCODE_BRIGHTNESS_UP,
            "BRIGHTNESS_DOWN" to KeyEvent.KEYCODE_BRIGHTNESS_DOWN,
            "CUT"            to KeyEvent.KEYCODE_CUT,
            "COPY"           to KeyEvent.KEYCODE_COPY,
            "PASTE"          to KeyEvent.KEYCODE_PASTE,
            "CONTACTS"       to KeyEvent.KEYCODE_CONTACTS,
            "CALENDAR"       to KeyEvent.KEYCODE_CALENDAR,
            "MUSIC"          to KeyEvent.KEYCODE_MUSIC,
            "EXPLORER"       to KeyEvent.KEYCODE_EXPLORER,
            "ENVELOPE"       to KeyEvent.KEYCODE_ENVELOPE,
            "HEADSETHOOK"    to KeyEvent.KEYCODE_HEADSETHOOK,
            "SYM"            to KeyEvent.KEYCODE_SYM,
        )
    }

    override suspend fun execute(args: Args): String {
        val key = args.keyName.uppercase().trim()
        val keyCode = KEY_MAP[key]
            ?: return "Failed: Unknown key '$key'. Supported keys: ${KEY_MAP.keys.sorted().joinToString()}"

        return withContext(Dispatchers.IO) {
            try {
                Instrumentation().sendKeyDownUpSync(keyCode)
                "Key '$key' sent successfully."
            } catch (e: Exception) {
                "Failed to send key '$key': ${e.message}"
            }
        }
    }
}
