package com.android.koogsystemonandroid.logging

import com.android.koogsystemonandroid.AppConfig
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 每个 WebSocket 连接对应一个 SessionLogger 实例。
 * 日志保存在 /sdcard/aiagent/YYYYMMDDHHMMSS.txt。
 */
class SessionLogger(clientIp: String, clientPort: Int) {

    private val logDir = File(AppConfig.LOG_DIR).also { it.mkdirs() }
    private val connectTime = Date()
    private val logFile: File

    init {
        val fileName = SimpleDateFormat("yyyyMMddHHmmss", Locale.getDefault())
            .format(connectTime) + ".txt"
        logFile = File(logDir, fileName)

        append("=== 连接建立 ===")
        append("客户端IP   : $clientIp")
        append("客户端端口 : $clientPort")
        append("连接时间   : ${fmt(connectTime)}")
        append("=================")
    }

    fun logUserMessage(message: String) {
        append("[${time()}] [用户] $message")
    }

    fun logAgentMessage(message: String) {
        append("[${time()}] [Agent] $message")
    }

    fun logDisconnect() {
        append("=================")
        append("断开时间   : ${fmt(Date())}")
        append("=== 连接结束 ===")
    }

    fun logError(error: String) {
        append("[${time()}] [错误] $error")
    }

    private fun append(line: String) {
        try {
            logFile.appendText(line + "\n")
        } catch (_: Exception) { }
    }

    private fun time() = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
    private fun fmt(d: Date) = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(d)
}
