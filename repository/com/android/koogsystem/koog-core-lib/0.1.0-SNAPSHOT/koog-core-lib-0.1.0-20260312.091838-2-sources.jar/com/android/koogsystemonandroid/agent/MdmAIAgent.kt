package com.android.koogsystemonandroid.agent

import ai.koog.agents.core.agent.AIAgentService
import ai.koog.agents.core.agent.config.AIAgentConfig
import ai.koog.agents.core.tools.ToolRegistry
import ai.koog.prompt.dsl.prompt
import ai.koog.prompt.executor.clients.deepseek.DeepSeekLLMClient
import ai.koog.prompt.executor.llms.SingleLLMPromptExecutor
import ai.koog.prompt.params.LLMParams
import android.content.Context
import com.android.koogsystemonandroid.tools.app.LaunchAppTool
import com.android.koogsystemonandroid.tools.device.SendKeyTool

// 主Agent入口
class MdmAIAgent(context: Context, private val config: AgentConfig) {

    private val toolRegistry = ToolRegistry {
        tool(LaunchAppTool(context))
        tool(SendKeyTool())
    }

    // 官方推荐: AIAgentService 工厂方法（0.6.4 使用 invoke 操作符）
    private val agentService = AIAgentService(
        promptExecutor = SingleLLMPromptExecutor(DeepSeekLLMClient(config.apiKey)),
        llmModel = config.model,
        systemPrompt = config.systemPrompt,
        toolRegistry = toolRegistry,
        maxIterations = config.maxIterations
    )

    // 存储多轮对话历史：Pair<用户消息, 助手回复>
    private val conversationHistory = mutableListOf<Pair<String, String>>()

    suspend fun run(userInput: String): String {
        // 每轮重建含历史对话的 AIAgentConfig 传给 createAgentAndRun
        val historyPrompt = prompt(id = "mdm-agent", params = LLMParams()) {
            system(config.systemPrompt)
            for ((userMsg, assistantMsg) in conversationHistory) {
                user(userMsg)
                assistant(assistantMsg)
            }
        }

        val agentConfig = AIAgentConfig(
            prompt = historyPrompt,
            model = config.model,
            maxAgentIterations = config.maxIterations
        )

        // 官方推荐: createAgentAndRun，每次传入含历史的 agentConfig 实现多轮对话
        val result = agentService.createAgentAndRun(userInput, agentConfig = agentConfig)

        conversationHistory.add(Pair(userInput, result))
        return result
    }

    /** 清空对话历史，开始新会话 */
    fun clearHistory() {
        conversationHistory.clear()
    }
}