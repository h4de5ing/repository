package com.android.koogsystemonandroid.agent

import ai.koog.prompt.executor.clients.deepseek.DeepSeekModels
import ai.koog.prompt.llm.LLModel

data class AgentConfig(
    val apiKey: String,
    val model: LLModel = DeepSeekModels.DeepSeekChat,
    val systemPrompt: String = DEFAULT_SYSTEM_PROMPT,
    val maxIterations: Int = 10
) {
    companion object {
        const val DEFAULT_SYSTEM_PROMPT = """
You are an MDM (Mobile Device Management) AI Agent with system-level privileges on this Android device.
You can control apps, device settings, and enforce policies.
When the user asks you to open, launch, or start an app, use the launch_app tool with the correct package name.
Always respond concisely and confirm what action you took.
        """
    }
}