package com.android.koogsystemonandroid

object AppConfig {
    const val DEEPSEEK_API_KEY = "sk-04d35e8a19524e50ba12d0efdcfcb14e"
    const val WS_PORT = 8765
    const val LOG_DIR = "/sdcard/aiagent"
}
