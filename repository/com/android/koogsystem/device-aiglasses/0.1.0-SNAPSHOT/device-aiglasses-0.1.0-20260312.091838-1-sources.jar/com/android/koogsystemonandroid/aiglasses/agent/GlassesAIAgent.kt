package com.android.koogsystemonandroid.aiglasses.agent

import ai.koog.agents.core.agent.AIAgentService
import ai.koog.agents.core.agent.config.AIAgentConfig
import ai.koog.agents.core.tools.ToolRegistry
import ai.koog.prompt.dsl.prompt
import ai.koog.prompt.executor.clients.deepseek.DeepSeekLLMClient
import ai.koog.prompt.executor.llms.SingleLLMPromptExecutor
import ai.koog.prompt.params.LLMParams
import android.content.Context
import android.util.Log
import com.android.koogsystemonandroid.aiglasses.tools.LaunchAppTool
import com.android.koogsystemonandroid.aiglasses.tools.TakePhotoTool
import com.android.koogsystemonandroid.aiglasses.tools.VideoRecordTool
import com.android.koogsystemonandroid.aiglasses.tools.VoiceRecordTool

class GlassesAIAgent(
    context: Context,
    private val config: GlassesAgentConfig = GlassesAgentConfig(),
) {
    private val toolRegistry = ToolRegistry {
        tool(TakePhotoTool())
        tool(VideoRecordTool())
        tool(VoiceRecordTool())
        tool(LaunchAppTool(context))
    }

    private val agentService = AIAgentService(
        promptExecutor = SingleLLMPromptExecutor(DeepSeekLLMClient(config.apiKey)),
        llmModel = config.model,
        systemPrompt = config.systemPrompt,
        toolRegistry = toolRegistry,
        maxIterations = config.maxIterations,
    )

    private val conversationHistory = mutableListOf<Pair<String, String>>()

    suspend fun run(userInput: String): String {
        ActionResultCollector.clear()
        ToolLogger.logSessionStart()
        ToolLogger.logConversationHistory(conversationHistory)
        ToolLogger.logUserInput(userInput)

        val historyPrompt = prompt(id = "glasses-agent", params = LLMParams()) {
            system(config.systemPrompt)
            for ((userMsg, assistantMsg) in conversationHistory) {
                user(userMsg)
                assistant(assistantMsg)
            }
        }

        val agentConfig = AIAgentConfig(
            prompt = historyPrompt,
            model = config.model,
            maxAgentIterations = config.maxIterations,
        )

        val result = agentService.createAgentAndRun(userInput, agentConfig = agentConfig)
        conversationHistory.add(userInput to result)
        ToolLogger.logAgentResult(result, ActionResultCollector.actions)
        Log.d(TAG, "Agent result: $result, actions: ${ActionResultCollector.actions}")
        return result
    }

    fun clearHistory() {
        conversationHistory.clear()
    }

    companion object {
        private const val TAG = "GlassesAIAgent"
    }
}
