package com.android.koogsystemonandroid.aiglasses.agent

import android.util.Log
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 工具执行日志记录器，将每一步操作写入日志文件，方便回顾是否真正执行。
 */
object ToolLogger {
    private const val TAG = "ToolLogger"
    private const val LOG_DIR = "/sdcard/aiglasses_log"

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    private val timeFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault())

    private fun getLogFile(): File {
        val dir = File(LOG_DIR).also { it.mkdirs() }
        val fileName = "tool_log_${dateFormat.format(Date())}.txt"
        return File(dir, fileName)
    }

    private fun now(): String = timeFormat.format(Date())

    private fun append(line: String) {
        try {
            getLogFile().appendText(line + "\n")
        } catch (e: Exception) {
            Log.e(TAG, "写入日志失败: ${e.message}")
        }
    }

    fun logUserInput(input: String) {
        append("[${now()}] [用户输入] $input")
    }

    fun logAgentResult(result: String, actions: List<String>) {
        append("[${now()}] [Agent回复] $result")
        append("[${now()}] [已执行动作] $actions")
    }

    fun logToolExecute(toolName: String, args: String) {
        append("[${now()}] [工具调用] $toolName | 参数: $args")
    }

    fun logToolResult(toolName: String, result: String) {
        append("[${now()}] [工具结果] $toolName | 结果: $result")
    }

    fun logToolError(toolName: String, error: String) {
        append("[${now()}] [工具异常] $toolName | 错误: $error")
    }

    fun logSessionStart() {
        append("")
        append("========== [${now()}] 新一轮对话开始 ==========")
    }

    fun logConversationHistory(history: List<Pair<String, String>>) {
        append("[${now()}] [历史轮数] ${history.size} 轮")
        history.forEachIndexed { i, (user, assistant) ->
            append("[${now()}] [历史#${i + 1}] 用户: $user | 助手: $assistant")
        }
    }
}
