package com.android.koogsystemonandroid.aiglasses.tools

import ai.koog.agents.core.tools.SimpleTool
import ai.koog.agents.core.tools.annotations.LLMDescription
import com.android.koogsystemonandroid.aiglasses.controller.EmdoorAIGlassesController
import kotlinx.serialization.Serializable

class VoiceRecordTool : SimpleTool<VoiceRecordTool.Args>(
    argsSerializer = Args.serializer(),
    name = "voice_record",
    description = "控制AI眼镜的录音功能。action为start表示开始录音，stop表示停止录音。",
) {
    @Serializable
    data class Args(
        @property:LLMDescription("操作类型：start=开始录音，stop=停止录音")
        val action: String,
    )

    private val controller = EmdoorAIGlassesController()

    override suspend fun execute(args: Args): String {
        return when (args.action.lowercase()) {
            "start" -> controller.startVoiceRecord()
            "stop" -> controller.stopVoiceRecord()
            else -> "无效操作：action 必须为 start 或 stop"
        }
    }
}
