package com.android.koogsystemonandroid.aiglasses.tools

import ai.koog.agents.core.tools.SimpleTool
import ai.koog.agents.core.tools.annotations.LLMDescription
import com.android.koogsystemonandroid.aiglasses.controller.EmdoorAIGlassesController
import kotlinx.serialization.Serializable

class TakePhotoTool : SimpleTool<TakePhotoTool.Args>(
    argsSerializer = Args.serializer(),
    name = "take_photo",
    description = "使用AI眼镜拍照。当用户说拍照、拍个照、照相等时调用此工具。",
) {
    @Serializable
    data class Args(
        @property:LLMDescription("固定为true，表示执行拍照")
        val confirm: Boolean = true,
    )

    private val controller = EmdoorAIGlassesController()

    override suspend fun execute(args: Args): String = controller.takePhoto()
}
