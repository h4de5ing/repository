package com.android.koogsystemonandroid.aiglasses.tools

import ai.koog.agents.core.tools.SimpleTool
import ai.koog.agents.core.tools.annotations.LLMDescription
import android.content.Context
import android.content.Intent
import com.android.koogsystemonandroid.aiglasses.agent.ActionResultCollector
import com.android.koogsystemonandroid.aiglasses.agent.ToolLogger
import kotlinx.serialization.Serializable

class LaunchAppTool(private val context: Context) : SimpleTool<LaunchAppTool.Args>(
    argsSerializer = Args.serializer(),
    name = "launch_app",
    description = "根据应用名称启动Android应用。当用户说打开XX、启动XX时调用此工具。支持中文和英文应用名。",
) {
    @Serializable
    data class Args(
        @property:LLMDescription("要打开的应用名称关键词（中文或英文均可）")
        val appName: String,
    )

    companion object {
        private val appAliases = mapOf(
            "火狐" to listOf("Firefox", "火狐浏览器"),
            "firefox" to listOf("火狐", "火狐浏览器"),
            "谷歌地图" to listOf("Google Maps", "Maps"),
            "谷歌浏览器" to listOf("Chrome", "谷歌"),
            "chrome" to listOf("谷歌浏览器", "谷歌"),
            "文件管理" to listOf("Files", "文件", "File Manager", "文件管理器"),
            "日历" to listOf("Calendar", "日历"),
            "计算器" to listOf("Calculator", "计算器"),
            "时钟" to listOf("Clock", "闹钟"),
            "邮件" to listOf("Email", "Gmail", "邮箱"),
            "音乐" to listOf("Music", "音乐"),
            "图库" to listOf("Gallery", "Photos", "相册"),
            "通讯录" to listOf("Contacts", "联系人"),
            "电话" to listOf("Phone", "拨号"),
            "短信" to listOf("Messages", "信息", "短信"),
            "设置" to listOf("Settings", "设置"),
            "相机" to listOf("Camera", "相机"),
        )

        fun getSearchKeywords(appName: String): List<String> {
            val keywords = mutableListOf(appName)
            for ((key, aliases) in appAliases) {
                if (appName.contains(key, ignoreCase = true) || key.contains(appName, ignoreCase = true)) {
                    keywords.addAll(aliases)
                }
            }
            return keywords.distinct()
        }
    }

    override suspend fun execute(args: Args): String {
        val searchKeywords = getSearchKeywords(args.appName)
        ToolLogger.logToolExecute("launch_app", "appName=${args.appName}, 搜索关键词=$searchKeywords")
        return try {
            val pm = context.packageManager
            val queryIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val appList = pm.queryIntentActivities(queryIntent, 0)
            for (resolveInfo in appList) {
                val appLabel = resolveInfo.loadLabel(pm).toString()
                val matched = searchKeywords.any { keyword ->
                    appLabel.contains(keyword, ignoreCase = true) || keyword.contains(appLabel, ignoreCase = true)
                }
                if (matched) {
                    val launchIntent = pm.getLaunchIntentForPackage(resolveInfo.activityInfo.packageName)
                    if (launchIntent != null) {
                        context.startActivity(launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                        ActionResultCollector.record(ActionResultCollector.ACTION_LAUNCH_APP)
                        val result = "已打开应用：$appLabel"
                        ToolLogger.logToolResult("launch_app", result)
                        return result
                    }
                }
            }
            val result = "未找到名称包含${args.appName}的应用（已尝试关键词：$searchKeywords）"
            ToolLogger.logToolResult("launch_app", result)
            result
        } catch (e: Exception) {
            val error = "启动应用异常: ${e.message}"
            ToolLogger.logToolError("launch_app", error)
            "操作失败：$error"
        }
    }
}
