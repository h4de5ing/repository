package com.android.koogsystemonandroid.aiglasses.controller

interface AIGlassesController {
    fun isReady(): Boolean
    suspend fun takePhoto(): String
    suspend fun startVideo(): String
    suspend fun stopVideo(): String
    suspend fun startVoiceRecord(): String
    suspend fun stopVoiceRecord(): String
}
