package com.android.koogsystemonandroid.aiglasses.controller

import com.android.koogsystemonandroid.aiglasses.agent.ActionResultCollector
import com.android.koogsystemonandroid.aiglasses.agent.ToolLogger
import com.emdoor.aiglasses.sdk.manager.DeviceManager
import com.emdoor.aiglasses.sdk.utils.Constant
import com.emdoor.aiglasses.sdk.utils.JsonBuilder

class EmdoorAIGlassesController : AIGlassesController {
    override fun isReady(): Boolean {
        val device = DeviceManager.getInstance().currentDevice ?: return false
        return device.isConnected && device.isGlassesTempleOpen
    }

    override suspend fun takePhoto(): String {
        ToolLogger.logToolExecute("take_photo", "confirm=true")
        return runCatching {
            ensureReady() ?: return@runCatching "操作失败：眼镜未就绪"
            DeviceManager.getInstance().sendBleJson(
                JsonBuilder.forObject()
                    .with(Constant.ACTION, Constant.ACT_CAMERA_CONTROL)
                    .with(Constant.TYPE, Constant.TAKE_PHOTO)
                    .build()
            )
            ActionResultCollector.record(ActionResultCollector.ACTION_TAKE_PHOTO)
            "已拍照"
        }.getOrElse {
            val error = "拍照异常: ${it.message}"
            ToolLogger.logToolError("take_photo", error)
            "操作失败：$error"
        }.also { ToolLogger.logToolResult("take_photo", it) }
    }

    override suspend fun startVideo(): String = video("start")

    override suspend fun stopVideo(): String = video("stop")

    override suspend fun startVoiceRecord(): String = voice("start")

    override suspend fun stopVoiceRecord(): String = voice("stop")

    private fun video(action: String): String {
        ToolLogger.logToolExecute("video_record", "action=$action")
        return runCatching {
            ensureReady() ?: return@runCatching "操作失败：眼镜未就绪"
            when (action.lowercase()) {
                "start" -> {
                    DeviceManager.getInstance().sendBleJson(
                        JsonBuilder.forObject()
                            .with(Constant.ACTION, Constant.ACT_CAMERA_VIDEO_CONTROL)
                            .with(Constant.TYPE, Constant.START_VIDEO_RECORD)
                            .build()
                    )
                    ActionResultCollector.record(ActionResultCollector.ACTION_START_VIDEO)
                    "已开始录像"
                }
                "stop" -> {
                    DeviceManager.getInstance().sendBleJson(
                        JsonBuilder.forObject()
                            .with(Constant.ACTION, Constant.ACT_CAMERA_VIDEO_CONTROL)
                            .with(Constant.TYPE, Constant.STOP_VIDEO_RECORD)
                            .build()
                    )
                    ActionResultCollector.record(ActionResultCollector.ACTION_STOP_VIDEO)
                    "已停止录像"
                }
                else -> "无效操作：action 必须为 start 或 stop"
            }
        }.getOrElse {
            val error = "录像操作异常: ${it.message}"
            ToolLogger.logToolError("video_record", error)
            "操作失败：$error"
        }.also { ToolLogger.logToolResult("video_record", it) }
    }

    private fun voice(action: String): String {
        ToolLogger.logToolExecute("voice_record", "action=$action")
        return runCatching {
            ensureReady() ?: return@runCatching "操作失败：眼镜未就绪"
            when (action.lowercase()) {
                "start" -> {
                    DeviceManager.getInstance().sendBleJson(
                        JsonBuilder.forObject()
                            .with(Constant.ACTION, Constant.ACT_SOUND_REC_CONTROL)
                            .with(Constant.TYPE, Constant.START_RECORDING_VOICE)
                            .build()
                    )
                    ActionResultCollector.record(ActionResultCollector.ACTION_START_VOICE)
                    "已开始录音"
                }
                "stop" -> {
                    DeviceManager.getInstance().sendBleJson(
                        JsonBuilder.forObject()
                            .with(Constant.ACTION, Constant.ACT_SOUND_REC_CONTROL)
                            .with(Constant.TYPE, Constant.STOP_RECORDING_VOICE)
                            .build()
                    )
                    ActionResultCollector.record(ActionResultCollector.ACTION_STOP_VOICE)
                    "已停止录音"
                }
                else -> "无效操作：action 必须为 start 或 stop"
            }
        }.getOrElse {
            val error = "录音操作异常: ${it.message}"
            ToolLogger.logToolError("voice_record", error)
            "操作失败：$error"
        }.also { ToolLogger.logToolResult("voice_record", it) }
    }

    private fun ensureReady(): Any? {
        val device = DeviceManager.getInstance().currentDevice ?: return null
        return if (device.isConnected && device.isGlassesTempleOpen) device else null
    }
}
