package com.android.koogsystemonandroid.aiglasses.agent

/**
 * 收集 Agent 工具执行结果，用于宿主侧处理副作用（如自动同步预览）。
 */
object ActionResultCollector {
    const val ACTION_TAKE_PHOTO = "TAKE_PHOTO"
    const val ACTION_START_VIDEO = "START_VIDEO"
    const val ACTION_STOP_VIDEO = "STOP_VIDEO"
    const val ACTION_START_VOICE = "START_VOICE"
    const val ACTION_STOP_VOICE = "STOP_VOICE"
    const val ACTION_LAUNCH_APP = "LAUNCH_APP"

    private val actionsInternal = mutableListOf<String>()
    val actions: List<String> get() = actionsInternal.toList()

    fun record(action: String) {
        actionsInternal.add(action)
    }

    fun clear() {
        actionsInternal.clear()
    }

    fun hasAction(action: String): Boolean = actionsInternal.contains(action)

    fun needsAutoSync(): Boolean = actionsInternal.any {
        it == ACTION_TAKE_PHOTO || it == ACTION_STOP_VIDEO || it == ACTION_STOP_VOICE
    }
}
