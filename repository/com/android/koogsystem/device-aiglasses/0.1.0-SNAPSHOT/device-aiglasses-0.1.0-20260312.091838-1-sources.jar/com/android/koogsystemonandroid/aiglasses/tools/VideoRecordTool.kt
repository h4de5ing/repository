package com.android.koogsystemonandroid.aiglasses.tools

import ai.koog.agents.core.tools.SimpleTool
import ai.koog.agents.core.tools.annotations.LLMDescription
import com.android.koogsystemonandroid.aiglasses.controller.EmdoorAIGlassesController
import kotlinx.serialization.Serializable

class VideoRecordTool : SimpleTool<VideoRecordTool.Args>(
    argsSerializer = Args.serializer(),
    name = "video_record",
    description = "控制AI眼镜的录像功能。action为start表示开始录像，stop表示停止录像。",
) {
    @Serializable
    data class Args(
        @property:LLMDescription("操作类型：start=开始录像，stop=停止录像")
        val action: String,
    )

    private val controller = EmdoorAIGlassesController()

    override suspend fun execute(args: Args): String {
        return when (args.action.lowercase()) {
            "start" -> controller.startVideo()
            "stop" -> controller.stopVideo()
            else -> "无效操作：action 必须为 start 或 stop"
        }
    }
}
