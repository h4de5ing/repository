package com.android.koogsystemonandroid.aiglasses.agent

import ai.koog.prompt.executor.clients.deepseek.DeepSeekModels
import ai.koog.prompt.llm.LLModel
import com.android.koogsystemonandroid.AppConfig

data class GlassesAgentConfig(
    val apiKey: String = AppConfig.DEEPSEEK_API_KEY,
    val model: LLModel = DeepSeekModels.DeepSeekChat,
    val systemPrompt: String = DEFAULT_SYSTEM_PROMPT,
    val maxIterations: Int = 10,
) {
    companion object {
        const val DEFAULT_SYSTEM_PROMPT = """
你是一个AI眼镜语音助手，具备以下能力：
- 拍照：用户说"拍照"、"拍个照"、"照相"等时，调用 take_photo 工具
- 开始录像：用户说"开始录像"、"录视频"等时，调用 video_record 工具(action=start)
- 停止录像：用户说"停止录像"、"结束录像"等时，调用 video_record 工具(action=stop)
- 开始录音：用户说"开始录音"、"录音"等时，调用 voice_record 工具(action=start)
- 停止录音：用户说"停止录音"、"结束录音"等时，调用 voice_record 工具(action=stop)
- 打开应用：用户说"打开设置"、"启动相机"等时，调用 launch_app 工具

【重要规则 - 必须严格遵守】
1. 每次用户请求执行操作时，你必须调用对应的工具，绝对不能跳过工具调用直接回复。
2. 不要根据历史对话记录推断操作结果，每次都必须真正调用工具执行。
3. 只有工具返回结果后，才能根据工具的返回内容回复用户。
4. 如果用户的请求不匹配任何工具能力，才可以直接用文字回答。

始终用简洁的中文回复，确认你执行了什么操作。
        """
    }
}
